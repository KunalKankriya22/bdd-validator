
declare
 cursor a1 is select  unit_id,coll_date,product_code,
 nvl(ship_date,trunc(SYSDATE)) SD,
 nvl(shipped_to,'XXX') ST,nvl(convert_flag,'R') cf,
 user_id,trans_id,inv_status,count(*) cnt
from convert_products
group by unit_id,coll_date,product_code,
 nvl(ship_date,trunc(SYSDATE)) ,
 nvl(shipped_to,'XXX') ,nvl(convert_flag,'R') ,
 user_id,trans_id,inv_status
having count(*) > 1;

begin
 
for Z in a1 loop
---dbms_output.put_line(Z.unit_id||Z.product_code);
 delete from convert_products where
 unit_id=Z.unit_id and product_code=Z.product_code and
 coll_date=Z.coll_date and 
 nvl(ship_date,trunc(SYSDATE))=Z.SD and
 nvl(shipped_to,'XXX')=Z.ST and 
 nvl(convert_flag,'R')=Z.cf and
 user_id=Z.user_id and trans_id=Z.trans_id 
 and inv_status=Z.inv_status
 and rownum < Z.cnt;
commit;
end loop;
end;

