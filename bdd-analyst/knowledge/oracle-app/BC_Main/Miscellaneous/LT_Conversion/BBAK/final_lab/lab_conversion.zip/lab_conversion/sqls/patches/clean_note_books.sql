DECLARE
 CURSOR note_cur is
    SELECT a.note_id note_id from note_books_edw a , note_books b
    where a.note_id=b.note_id and rownum <20000;

commit_count NUMBER:=0;
nCount number:=0;
pCount number:=0;

BEGIN

   FOR Z1 in note_cur LOOP
       ncount:=0;
       pCount:=0;

       select nvl(count(*),0) into ncount  from units
       where note_id is not null and nvl(note_id,99)=Z1.note_id;

       If ncount > 0 then 
         null;
       Else
          select nvl(count(*) ,0) into pCount from components 
          where note_id is not null and nvl(note_id,99)=Z1.note_id;

          If pCount > 0 then 
             null;
          Else
             delete from note_books where note_id=Z1.note_id;
             commit_count:=commit_count+1;
             if commit_count >=300 then 
                commit;
                dbms_output.put_line('Count='||to_char(commit_count));
                commit_count:=0;
             end if;

          End if;
       End If;

   END LOOP;

   commit;
   dbms_output.put_line('Deleted='||to_char(commit_count));
END;
/
