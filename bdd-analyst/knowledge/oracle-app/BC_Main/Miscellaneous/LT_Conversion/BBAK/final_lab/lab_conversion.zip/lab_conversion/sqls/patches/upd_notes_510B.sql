-- ************************************************************************
-- PROGRAM      : TX_PRODUCTS_LAB.SQL
-- PURPOSE      : This script would convert all the data of products of 
--                into components table for forthur processing 
--                LifeTrak /Lab - Distribution tables.
-- date modified: 02/07/10   Edwin
-- ************************************************************************
DECLARE
  last_id             varchar2(15);
  l_audit_seq     number := 0;
  l_notebook_seq  number := 0; 
  cnt             number:=0; 
  tot_cnt         number  :=0;
  lDonType        varchar2(5);
  lProcType       varchar2(4);
  c_product_code  varchar2(8);
  c_product_type  varchar2(5);
  c_aliquot       varchar2(2);
  c_temp_seq      number := 0;
  c_user_id       varchar2(8);
  c_status        varchar2(1);
  c_blood_type    varchar2(4);
  C_temp_cnt      number := 0;
  c_stmt          number(5);
  c_err_msg       varchar2(100);
  c_err_flg       varchar2(1);
  c_err_cd        varchar2(2);
  c_insert_user   varchar2(6);
  pgm_error       exception;
  c_error_cnt     number :=0;
  c_item_id       varchar2(30);
  c_exit_flg      varchar2(1):='N';
  c_note_id       varchar2(10);
  c_note_text     varchar2(1000);
  v_pgm_id     varchar2(10);
  c_coll_date    date;
  sld_date        date;
  sld_user        varchar2(30);
  nAliCount    number:=0;
  DupCount   number:=0;
  nVOl    NUMBER:=0;
  szStatusInd  varchar2(5); 
 ltUnit_id  varchar2(13);
  temp_unit_id varchar2(13);
  szReject varchar2(10);
  szRelabel  varchar2(10);
  szCompPrefix  VARCHAR2(2);
  location   varchar2(20);
  ncount  number:=0;
  v_intended_use varchar2 (2);
  unit_scheme   varchar2(1);
  nUnitCounts  NUMBER:=0;
  cursor c1 is
    select * from convert_products where trans_id in ('062','090','060');
   
BEGIN    --Main begin

v_pgm_id:='510A';

dbms_output.enable(10000000);
 FOR c1_rec in c1
  loop
    Begin

        ltUnit_id:=c1_rec.unit_id;

        If ltUnit_id like 'W%' and length (ltUnit_id)> 7 then
           unit_scheme:='I';
        Else
           unit_scheme:='C';
        End If;

        select product_code,inv_product_type
              into c_product_code,c_product_type
              from valid_products
              where UPPER(ltrim(rtrim(product_short_name)))=c1_rec.product_code
              and unit_scheme_type=unit_scheme and rownum =1; 
         
         If ltUnit_id like 'W%' and length(ltUnit_id)> 7 then
           --find the intended use
            begin       
               select m.code_desc into v_intended_use from master_codes m,
               unit_attributes ua where ua.unit_id=ltUnit_id and
               ua.attrib_group='DON' and ua.attrib_code=m.code and
               m.code_type='IUSE';
            exception when others then 
                 v_intended_use:='V';
            end;
         
            c_product_code:=c_product_code||v_intended_use ||
                            nvl(c1_rec.aliquot,'00');
         End if;

      If c1_rec.trans_id in ('061','090','062')then
         select notebook_seq.nextval into c_note_id from dual;
         insert into note_books values (c_note_id,c1_rec.trans_id_f1||' '||
                                        c1_rec.trans_id_f2);
         update components set note_id=c_note_id where
         unit_id=ltUnit_id and product_code=c_product_code;
      End If;


  Exception
        when no_data_found then
          null;
        when others then
           null;
   End;

   commit;

  end loop;
  commit;

EXCEPTION WHEN others then
  dbms_output.put_line(c_err_msg);
END;
/
