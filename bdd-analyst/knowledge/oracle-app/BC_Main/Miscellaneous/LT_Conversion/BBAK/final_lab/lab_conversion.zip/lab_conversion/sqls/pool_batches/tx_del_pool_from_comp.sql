declare
  cursor pooled_units is select pool_id from pooled_components;
begin
for z in pooled_units loop
  delete from components where unit_id=z.pool_id;
 end loop;
 commit;
end;

