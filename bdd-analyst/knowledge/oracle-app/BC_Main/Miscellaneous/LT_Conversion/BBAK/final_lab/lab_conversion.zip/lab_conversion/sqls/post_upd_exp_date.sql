Declare
  cursor c1 is select * from convert_products 
               where convert_flag='X' and
               expiry_date is not null and shipped_to='DISC';

  pl_life  number;
  pl_ind   varchar2(1);
  pl_days  number:=0;
  pl_exp_date  DATE;
  ltUnit_id   varchar2(15);
  c_product_code   varchar2(8);
  v_intended_use varchar2(1);

Begin
  FOR c1_rec in c1 loop

     -- get the product code

        Begin
      ltUnit_id :=c1_rec.unit_id;

      begin
       select product_code
             into c_product_code
             from valid_products
        where ltrim(rtrim(product_short_name))=RTrim(c1_rec.product_code)
              and unit_scheme_type=decode(length(c1_rec.unit_id),7,'C','I')
              and rownum =1;
              --c_product_code:=c_product_code||'V'||00;
     exception
       when others then
          null;
     end;

    If Length(c1_rec.unit_id)>7 then
       begin
         select m.code_desc into v_intended_use from master_codes m,
         unit_attributes ua where ua.unit_id=ltUnit_id and
          ua.attrib_group='DON' and ua.attrib_code=m.code and
          m.code_type='IUSE';
       exception when others then
          v_intended_use:='V';
       end;
       c_product_code:=c_product_code||v_intended_use ||
                           nvl(c1_rec.aliquot,'00');
     End if;
  

     UPDATE components set expiry_date=c1_rec.expiry_date where
     unit_id=C1_rec.unit_id and product_code=c_product_code ;
    commit;
  exception when no_data_found then 
     dbms_output.put_line('No record='||c1_rec.product_code);
  end;

  End Loop;
END;

/
commit
/



