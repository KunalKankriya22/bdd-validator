truncate table COMPONENT_DIFF_DET;
delete from COMPONENT_DIFF_HDR;
truncate table COMPONENT_SP;
truncate table COMPONENT_SP_REAG_HDR;
truncate table COMPONENT_SP_REAG_DET ;
delete from pooled_components;
delete from component_interdictions;
delete from components;

