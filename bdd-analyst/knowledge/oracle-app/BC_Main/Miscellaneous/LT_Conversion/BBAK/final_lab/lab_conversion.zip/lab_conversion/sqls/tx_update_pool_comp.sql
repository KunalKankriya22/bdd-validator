-- ************************************************************************
-- PROGRAM      : TX_PRODUCTS.SQL
-- PURPOSE      : This script would convert all the data of products of 
--                pooled_products 
--                LifeTrak /Lab - Distribution tables.
-- ************************************************************************
DECLARE
  last_id             varchar2(15);
  l_audit_seq     number := 0;
  l_notebook_seq  number := 0; 
  cnt             number(5):=0; 
  tot_cnt         number  :=0;
  lDonType        varchar2(5);
  lProcType       varchar2(4);
  c_product_code  varchar2(8);
  c_product_type  varchar2(5);
  c_aliquot       varchar2(2);
  c_temp_seq      number := 0;
  c_pick_slip     varchar2(10);
  c_ship_ticket   varchar2(14);
  c_box           varchar2(10);
  c_order         varchar2(14);
  c_customer      varchar2(10);
  c_payee         varchar2(10);
  c_ship_cnt      number := 0;
  dup_flag        varchar2(1);
  c_attrib_code   varchar2(4);
  c_user_id       varchar2(8);
  c_dest_code     varchar2(10);
  c_consignee     varchar2(10);
  c_bag_code      varchar2(4);
  c_status        varchar2(1);
  c_price         number := 0;
  c_temp_price    number := 0;
  c_blood_type    varchar2(4);
  c_temp_cnt      number := 0;
  c_stmt          number(5);
  c_err_msg       varchar2(100);
  c_err_flg       varchar2(1);
  c_err_cd        varchar2(2);
  c_insert_user   varchar2(6);
  pgm_error       exception;
  c_error_cnt     number :=0;
  c_item_id       varchar2(30);
  c_exit_flg      varchar2(1):='N';
  c_note_id       varchar2(10);
  c_note_text     varchar2(1000);
  szCompPrefix    varchar2(3);
  c_attrib_code   varchar2(4);
  v_pgm_id     varchar2(10);
  c_coll_date    date;
  nAliCount    number:=0;
  DupCount   number:=0;
  nVol    number:=0;
  ltUnit_id    varchar2(15);
  temp_unit_id  varchar2(15);
  v_intended_use  varchar2(4);
  nUnitCounts   number:=0;
  nCount        number:=0;

  cursor c1 is
    select * from convert_products
    where pool_id is not null;

procedure insert_error is
  begin
    c_error_cnt := c_error_cnt +1;

    if c_error_cnt>10000 then
      c_err_msg := 'Reached maximum no of errors';
      c_exit_flg := 'Y';
    end if;

    ---c_stmt := 101;
    insert into program_errors( module_id,
                                program_id,
                                statement_id,
                                item_id,
                                error_msg,
                                insert_user,
                                insert_date)
        values( 'ACTIVECONV',
                                'TX_PRODUCTS',
                                c_stmt,
                                c_item_id,
                                substr(c_err_msg,1,240),
                                'CONVRT',
                                sysdate);
  Exception when others then
    dbms_output.put_line('Insert into error='||sqlerrm); 
     null;
  end;

BEGIN    --Main begin

v_pgm_id:='510P';

dbms_output.enable(10000000);
 FOR c1_rec in c1
  loop
    Begin
      ltUnit_id :=c1_rec.unit_id;

      begin
       select product_code
             into c_product_code
             from valid_products
        where ltrim(rtrim(product_short_name))=RTrim(c1_rec.product_code)
              and unit_scheme_type='I' and rownum =1;
              --c_product_code:=c_product_code||'V'||00;
     exception
           when no_data_found then
             --c_product_code := c1_rec.product_code;
             c_err_msg :=c1_rec.product_code||
                  ' No Data in the product code table';
             raise pgm_error;
       when others then
          c_err_msg:=c1_rec.product_code||'-'||sqlerrm;
     end;

       begin
       select m.code_desc into v_intended_use from master_codes m,
        unit_attributes ua where ua.unit_id=ltUnit_id and
        ua.attrib_group='DON' and ua.attrib_code=m.code and
        m.code_type='IUSE';
      exception when others then
        v_intended_use:='V';
      end;
          c_product_code:=c_product_code||v_intended_use ||
                                 nvl(c1_rec.aliquot,'00');



     update components set pooled_component_id=c1_rec.pool_id,
      reject_reason_code='POOL'   -- added on 07/19/14
     where unit_id=c1_rec.unit_id and product_code=c_product_code;

  
        commit;  -- Commit the transaction for every 100 records.
   Exception
      when pgm_error then
        c_item_id := ltUnit_id;
        --dbms_output.put_line('Basker='||sqlerrm);
            insert_error;
      when others then
            c_err_msg := substr(sqlerrm,1,100);
        c_item_id := ltUnit_id;
      dbms_output.put_line(c_item_id ||' '||c_err_msg);
        insert_error;
   End;
  end loop;
  commit;
END;
/
