declare
  cursor pooled_units is select pool_id,product_code,pool_expiry_dats
    from pooled_components;
  pl_exp_date  date;
begin
for z in pooled_units loop
  --update components set reject_reason_code='POOL' where
  --pooled_component_id=z.pool_id;

  --get expiry date from components
  begin
    select expiry_date into pl_exp_date from components where
    unit_id=z.pool_id and product_code=z.product_code and rownum=1;
  exception when others then 
    pl_exp_date:=z.pool_expiry_dats;
  end;
   update pooled_components set pool_expiry_dats=pl_exp_date where
   pool_id=z.pool_id and product_code=z.product_code;

  update units set contract_id='POOL' where unit_id=z.pool_id;

 end loop;
 commit;
end;

