update convert_products set shipped_to='DISC' where 
convert_flag='X';
update convert_products set shipped_to='TRAN' where
trans_id='015';
update convert_products set shipped_to='POOL' where
trans_id='027';
update convert_products set shipped_to='DISC' where
trans_id='035';
update convert_products set shipped_to='MISC' where
shipped_to is null;
update convert_products set shipped_to='MISC' where
shipped_to not in (select short_name from customers); 

