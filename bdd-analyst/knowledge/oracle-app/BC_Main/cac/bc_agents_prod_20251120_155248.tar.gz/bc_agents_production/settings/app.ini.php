;<?php die(); ?>
[application]
app_name = BC_Agents
app_version = 2.0.0
log_level = INFO
log_retention_days = 30

[security]
session_timeout = 3600
max_login_attempts = 5
lockout_duration = 900

[performance]
cache_enabled = true
cache_ttl = 300
