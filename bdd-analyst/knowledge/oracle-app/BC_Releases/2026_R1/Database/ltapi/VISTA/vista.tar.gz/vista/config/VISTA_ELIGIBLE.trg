CREATE OR REPLACE TRIGGER OPS$DONSYS.VISTA_ELIGIBLE
 AFTER INSERT OR UPDATE OF HLTH_HIST_END
, PHY_FINDINGS_END
 ON ONLINE_STATUS
 FOR EACH ROW
DECLARE
   v_vista VARCHAR2(10) := 'N';
   v_ct    NUMBER := 0;
BEGIN
   SELECT max(parameter_value) INTO v_vista
     FROM valid_parameters
    WHERE parameter_code = 'IDP_FCN';
    IF v_vista = 'Y'
       AND :new.hlth_hist_end IS NOT NULL
       AND :new.phy_findings_end IS NOT NULL THEN
       SELECT count(v.last_modified_date) INTO v_ct
	 FROM vis_eligibility v
	 WHERE v.transaction_id = :new.transaction_id;
       IF v_ct = 0 THEN
	 donor_idp.update_vis_eligibility('I',:new.transaction_id);
       ELSE
	 donor_idp.update_vis_eligibility('U',:new.transaction_id);
       END IF;
    END IF;
END;
/

Show Errors

Alter TRIGGER OPS$DONSYS.VISTA_ELIGIBLE enable;

exit;
