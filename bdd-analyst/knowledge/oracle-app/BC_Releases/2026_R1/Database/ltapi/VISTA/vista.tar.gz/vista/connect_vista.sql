connect ops$vista/vista@qdon

