PATH=/usr/local/bin:$PATH/:/home/donsys/vista:.:$HOME
ORACLE_SID=qdon;export ORACLE_SID
UTIL_FILE_DIR=/tmp/qdon_util
ORAENV_ASK=NO
. oraenv
ORACLE_PATH=$ORACLE_PATH:/home/donsys/vista;export ORACLE_PATH
cd $HOME/vista/results
for i in *.*
do
if [ -f $i ]
then
cp $i $UTIL_FILE_DIR/$i.don
sqlplus / @connect_vista.sql <<!
@vista_donation.sql $i.don
exit
!
mv $i save
fi
done

