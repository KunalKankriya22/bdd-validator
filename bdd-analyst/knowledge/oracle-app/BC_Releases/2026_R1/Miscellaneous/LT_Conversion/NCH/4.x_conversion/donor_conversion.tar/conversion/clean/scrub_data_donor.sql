set pagesize 500
set linesize 200
set verify off
set feedback off
set termout off
set heading off

connect ops$donsys/phUjub@pdon

spool donor_data_clear.sql

SELECT 'truncate table '||table_name||';'
  FROM user_tables WHERE table_name not in 
  ('ADDRESSES',
  'BAR_CODE_PREFIXES',
  'DONOR_GRADING_MATRIX',
  'DGM_ADDRESSES',
  'DGM_FIRSTNAMES',
  'DGM_LASTNAMES',
  'DGM_NICKNAMES',
  'EMPLOYEES' ,
  'LOCATIONS',
  'MEDICINES',
  'NAME_MATCH',
  'NICKNAMES',
  'SPONSORS',
  'DRIVES',
  'SPONSOR_CONTACTS' ,
  'FIND_DONOR_PROGRAMS',
  'FIND_DONOR_FIELDS',
  'HEALTH_HISTORY_TEMPLATE',
  'PHYSICAL_FINDINGS_TEMPLATE',
  'ALL_DONOR_IDS'
 'FIXED_SITE_ATTRIBUTES') and 
 table_name not like 'VALID%';
  

spool off

spool donor_audit_clear.sql

SELECT 'truncate table '||table_name||';'
  FROM user_tables WHERE table_name LIKE '%AUDIT';

spool off

