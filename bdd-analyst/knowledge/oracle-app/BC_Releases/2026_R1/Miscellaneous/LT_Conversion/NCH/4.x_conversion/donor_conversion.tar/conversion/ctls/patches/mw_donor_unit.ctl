LOAD DATA
INFILE '/home/donsys/conversion/data/table.PRC'
---APPEND
INTO TABLE mw_donor_unit
(
 UNIT_ID        POSITION(1:15)          CHAR  NULLIF (UNIT_ID = BLANKS),
 COLL_DATE      POSITION(16:23)         DATE(8) "MMDDYYYY"  NULLIF (COLL_DATE = BLANKS),
 DONOR_ID       POSITION(24:33)         CHAR  NULLIF (DONOR_ID = BLANKS)
)
