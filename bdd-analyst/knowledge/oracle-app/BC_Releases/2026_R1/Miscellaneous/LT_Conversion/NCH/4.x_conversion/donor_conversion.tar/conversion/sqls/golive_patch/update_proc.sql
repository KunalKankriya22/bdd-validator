DECLARE
---
   CURSOR CUR_DI is
      SELECT donor_id,unit_id,coll_date from 
             mw_donor_unit;

   i_recs           number:=0;
   n_period         NUMBER:=0;
   n_days           NUMBER:=0;
   v_term_days      NUMBER:=0;
   v_date_time   varchar2(20);
   i_rec            NUMBER:=0;

BEGIN
   dbms_output.enable(1000000);

---
   SELECT to_char(sysdate,'MM/DD/YYYY HH24:MI:SS') into v_date_time
     FROM dual;
   
   dbms_output.put_line('Script Start Time : '||v_date_time);
   FOR currec in cur_di LOOP

       UPDATE donations set procedure_code='ZZ' where 
       unit_id=currec.unit_id and donor_id=currec.donor_id;
       commit;

   END LOOP;
   COMMIT;
END; 

