LOAD DATA
INFILE '/home/donsys/conversion/zipcode/zip_code.data'
---APPEND
INTO TABLE city_state_zip
(
 CITY            POSITION(1:32)          CHAR  NULLIF (CITY = BLANKS),
 STATE           POSITION(33:34)         CHAR  NULLIF (STATE = BLANKS),
 ZIP             POSITION(39:43)         CHAR  NULLIF (ZIP   = BLANKS)
)
