update convert_products c  set coll_date=(select coll_date from convert_units u
where c.unit_id=u.unit_id and u.coll_date is not null and rownum=1)
/

commit
/

