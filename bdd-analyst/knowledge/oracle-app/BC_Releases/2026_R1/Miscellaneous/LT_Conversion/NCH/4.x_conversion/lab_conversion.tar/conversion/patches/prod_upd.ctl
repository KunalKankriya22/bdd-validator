LOAD DATA
INFILE '/mediwarehome/sbcsys/conversion/patches/prod_upd.dat'
append
INTO TABLE convert_prod_patch
(
 PRODUCT_CODE   POSITION(001:008)   CHAR(8)  NULLIF (PRODUCT_CODE = BLANKS),
 UNIT_ID        POSITION(009:015)   CHAR(15) NULLIF (UNIT_ID = BLANKS)
)

