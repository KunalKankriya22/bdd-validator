-- ************************************************************************
-- PROGRAM      : PROD_UPD.sql
-- PURPOSE      : This script to flag the unit and Products in the Lab 
-- ************************************************************************
DECLARE
  tot_cnt         number  :=0;
  c_product_code  varchar2(8);
  c_product_type  varchar2(5);
  v_unit_id       varchar2(15);
  c_stmt          number(5);
  
cursor c1 is
 select * from convert_prod_patch;

BEGIN    --Main begin

dbms_output.enable(10000000);
 FOR c1_rec in c1
  loop
    ---dbms_output.putline(c1_rec.unit_id);

/*
    begin
        c_stmt := 12;
        select product_code
              into c_product_code
              from valid_products
         where UPPER(ltrim(rtrim(product_short_name)))=c1_rec.product_code
               and rownum =1;  
    exception
            when no_data_found then
              dbms_output.put_line('Invalid='||c1_rec.product_code);
    end;

   */

    update convert_products set component_mask='X',
    shipped_to=null,ship_ticket_no=null  where 
    unit_id=c1_rec.unit_id and product_code=c1_rec.product_code;

  end loop;
END;

