-- ************************************************************************
-- PROGRAM      : CLEAN_UNITS.SQL
-- PURPOSE      : This script would clean the units table
-- ************************************************************************
DECLARE
  cnt             number(5):=0; 
  tot_cnt         number  :=0;
  bCount        number:=0;  
  v_coll_date   Date;
  cursor c1 is
   select distinct unit_id donation_id from components where rownum <10;
BEGIN    --Main begin
dbms_output.enable(1000000);
 FOR c1_rec in c1
  loop
    begin
      cnt := cnt+1;
      tot_cnt := tot_cnt +1;
      begin
        v_coll_date:=null;
        select coll_date into v_coll_date from convert_units where
        unit_id=c1_rec.donation_id;
      exception when others then
         v_coll_date:=null;
     end; 
     
    If v_coll_date is not null then 
      update product_history set coll_date=v_coll_date
      where unit_id=c1_rec.donation_id;
     
       update shipped_products set coll_date=v_coll_date
      where unit_id=c1_rec.donation_id;
      
       update pick_slip_products set coll_date=v_coll_date
      where unit_id=c1_rec.donation_id;
    End If;

     if cnt > 10 then
        commit;  -- Commit the transaction for every 100 records.
            cnt          := 0;
      end if;
      dbms_output.put_line(to_char(tot_cnt));
     exception when others then
    dbms_output.put_line(sqlerrm); 
   end;
  end loop;

  commit;
END;
/
